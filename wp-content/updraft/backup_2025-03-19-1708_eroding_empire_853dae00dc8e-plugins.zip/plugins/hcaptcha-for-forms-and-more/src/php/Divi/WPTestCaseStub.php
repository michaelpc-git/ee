<?php
/**
 * Codeception\TestCase\WPTestCase stub file.
 *
 * @package hcaptcha-wp
 * @noinspection AutoloadingIssuesInspection
 */

// phpcs:ignore Generic.Commenting.DocComment.MissingShort
/** @noinspection PhpIllegalPsrClassPathInspection */
namespace Codeception\TestCase;

/**
 * Stub of the Codeception\TestCase\WPTestCase class.
 */
class WPTestCase {
}
