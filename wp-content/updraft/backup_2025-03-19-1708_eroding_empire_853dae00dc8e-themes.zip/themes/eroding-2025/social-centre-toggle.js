$(document).ready(function () {
    $("#56a").click(function () {
        $("#56a-content").toggle();
    });
});
