<?php if (!defined('WPO_VERSION')) die('No direct access allowed'); ?>

<div id="wpo-status-report-container">
	<label id="wpo-generate-status-report-text"></label>
</div>