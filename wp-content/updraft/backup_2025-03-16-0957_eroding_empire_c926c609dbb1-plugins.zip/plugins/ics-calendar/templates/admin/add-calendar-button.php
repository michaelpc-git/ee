<a href="#" class="button r34ics_media_link add_r34ics" id="add_r34ics_<?php echo esc_attr(r34ics_uid()); ?>" title="<?php
/* translators: 1: Plugin name (do not translate) */
printf(esc_attr__('Add %1$s', 'ics-calendar'), 'ICS Calendar');
?>"><div class="r34ics_media_icon">&nbsp;</div><?php
/* translators: 1: Plugin name (do not translate) */
printf(esc_html__('Add %1$s', 'ics-calendar'), 'ICS Calendar');
?></a>
