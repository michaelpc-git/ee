<?php exit('Access denied'); __halt_compiler(); ?>
******************************************************************
This file is used by the Wordfence Web Application Firewall. Read 
more at https://docs.wordfence.com/en/Web_Application_Firewall_FAQ
******************************************************************
a:5:{s:9:"wafStatus";s:13:"learning-mode";s:30:"learningModeGracePeriodEnabled";i:1;s:23:"learningModeGracePeriod";i:1742689144;s:7:"authKey";s:64:"&(9CJb<E8!*]`:gqh=2Gpog|QAc)?/3!sh5+25^%}?,|h:K%p,* iq2e8-u$i3sV";s:7:"version";s:5:"1.1.0";}