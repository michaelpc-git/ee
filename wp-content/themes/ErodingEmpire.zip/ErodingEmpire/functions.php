<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// BEGIN ENQUEUE PARENT ACTION
// AUTO GENERATED - Do not modify or remove comment markers above or below:

if ( !function_exists( 'chld_thm_cfg_locale_css' ) ):
    function chld_thm_cfg_locale_css( $uri ){
        if ( empty( $uri ) && is_rtl() && file_exists( get_template_directory() . '/rtl.css' ) )
            $uri = get_template_directory_uri() . '/rtl.css';
        return $uri;
    }
endif;
add_filter( 'locale_stylesheet_uri', 'chld_thm_cfg_locale_css' );
         
if ( !function_exists( 'child_theme_configurator_css' ) ):
    function child_theme_configurator_css() {
        wp_enqueue_style( 'chld_thm_cfg_separate', trailingslashit( get_stylesheet_directory_uri() ) . 'ctc-style.css', array(  ) );
    }
endif;
add_action( 'wp_enqueue_scripts', 'child_theme_configurator_css', 10 );

if ( !function_exists( 'main_css' ) ):
    function main_css() {
        wp_enqueue_style( 'maincss', trailingslashit( get_stylesheet_directory_uri() ) . 'main.css', array(  ) );
    }
endif;
add_action( 'wp_enqueue_scripts', 'main_css', 10 );
if ( !function_exists( 'home_css' ) ):
    function home_css() {
		if ( is_page( 'eroding-empire' ) ) {
        wp_enqueue_style( 'homecss', trailingslashit( get_stylesheet_directory_uri() ) . 'home.css', array(  ) );
		}
    }
endif;
add_action( 'wp_enqueue_scripts', 'home_css', 10 );
if ( !function_exists( 'submit_css' ) ):
    function submit_css() {
		if ( is_page( 'submit' ) ) {
        wp_enqueue_style( 'submitcss', trailingslashit( get_stylesheet_directory_uri() ) . 'submit.css', array(  ) );
		}
    }
endif;
add_action( 'wp_enqueue_scripts', 'submit_css', 10 );
if ( !function_exists( 'news_css' ) ):
    function news_css() {
		if ( is_page( 'news' ) ) {
        wp_enqueue_style( 'newscss', trailingslashit( get_stylesheet_directory_uri() ) . 'news.css', array(  ) );
		}
    }
endif;
add_action( 'wp_enqueue_scripts', 'news_css', 10 );
if ( !function_exists( 'categories_css' ) ):
    function categories_css() {
		if ( is_tax( 'category' ) ) {
        wp_enqueue_style( 'categoriescss', trailingslashit( get_stylesheet_directory_uri() ) . 'news.css', array(  ) );
		}
    }
endif;
add_action( 'wp_enqueue_scripts', 'categories_css', 10 );
if ( !function_exists( 'calendar_css' ) ):
    function calendar_css() {
		if ( is_page( 'calendar' ) ) {
        wp_enqueue_style( 'calendarcss', trailingslashit( get_stylesheet_directory_uri() ) . 'calendar.css?ver=7', array(  ) );
		}
    }
endif;

add_action( 'wp_enqueue_scripts', 'calendar_css', 10 );
if ( !function_exists( 'contact_css' ) ):
    function contact_css() {
		if ( is_page( 'contact' ) ) {
        wp_enqueue_style( 'contactcss', trailingslashit( get_stylesheet_directory_uri() ) . 'contact.css', array(  ) );
		}
    }
endif;
add_action( 'wp_enqueue_scripts', 'contact_css', 10 );
if ( !function_exists( 'archives_css' ) ):
    function archives_css() {
		if ( is_page( 'archives' ) ) {
        wp_enqueue_style( 'archivescss', trailingslashit( get_stylesheet_directory_uri() ) . 'archives.css', array(  ) );
		}
    }
endif;
add_action( 'wp_enqueue_scripts', 'archives_css', 10 );
if ( !function_exists( 'webarchive_css' ) ):
    function webarchive_css() {
		if ( is_page( 'archives/webarchive' ) ) {
        wp_enqueue_style( 'webarchivecss', trailingslashit( get_stylesheet_directory_uri() ) . 'webarchive.css', array(  ) );
		}
    }
endif;
add_action( 'wp_enqueue_scripts', 'webarchive_css', 10 );
if ( !function_exists( 'zines_css' ) ):
    function zines_css() {
		if ( is_post_type_archive( 'zine' ) ) {
        wp_enqueue_style( 'zinescss', trailingslashit( get_stylesheet_directory_uri() ) . 'zines.css', array(  ) );
		};
		if ( is_singular( 'zine' ) ) {
        wp_enqueue_style( 'zinescss', trailingslashit( get_stylesheet_directory_uri() ) . 'zines.css', array(  ) );
		}
    }
endif;
add_action( 'wp_enqueue_scripts', 'zines_css', 10 );
if ( !function_exists( 'topics_css' ) ):
    function topics_css() {
		if ( is_tax( 'topic' ) ) {
        wp_enqueue_style( 'topicscss', trailingslashit( get_stylesheet_directory_uri() ) . 'zines.css', array(  ) );
		}
    }
endif;
add_action( 'wp_enqueue_scripts', 'topics_css', 10 );
if ( !function_exists( 'social_centres_css' ) ):
    function social_centres_css() {
		if ( is_post_type_archive( 'social_centre' ) ) {
        wp_enqueue_style( 'social_centrescss', trailingslashit( get_stylesheet_directory_uri() ) . 'social_centres.css', array(  ) );
		};
		if ( is_singular( 'social_centre' ) ) {
        wp_enqueue_style( 'social_centrescss', trailingslashit( get_stylesheet_directory_uri() ) . 'social_centres.css', array(  ) );	
		}
    }
endif;
add_action( 'wp_enqueue_scripts', 'social_centres_css', 10 );
if ( !function_exists( 'squats_css' ) ):
    function squats_css() {
		if ( is_post_type_archive( 'squat' ) ) {
        wp_enqueue_style( 'squatscss', trailingslashit( get_stylesheet_directory_uri() ) . 'squats.css', array(  ) );
		}
		if ( is_singular( 'squat' ) ) {
        wp_enqueue_style( 'squatscss', trailingslashit( get_stylesheet_directory_uri() ) . 'squats.css', array(  ) );
		}
    }
endif;
add_action( 'wp_enqueue_scripts', 'squats_css', 10 );

// END ENQUEUE PARENT ACTION

function revcon_change_post_label() {
    global $menu;
    global $submenu;
    $menu[5][0] = 'News';
    $submenu['edit.php'][5][0] = 'News';
    $submenu['edit.php'][10][0] = 'Add News';
    $submenu['edit.php'][16][0] = 'News Tags';
}
function revcon_change_post_object() {
    global $wp_post_types;
    $labels = &$wp_post_types['post']->labels;
    $labels->name = 'News';
    $labels->singular_name = 'News';
    $labels->add_new = 'Add News';
    $labels->add_new_item = 'Add News';
    $labels->edit_item = 'Edit News';
    $labels->new_item = 'News';
    $labels->view_item = 'View News';
    $labels->search_items = 'Search News';
    $labels->not_found = 'No News found';
    $labels->not_found_in_trash = 'No News found in Trash';
    $labels->all_items = 'All News';
    $labels->menu_name = 'News';
    $labels->name_admin_bar = 'News';
}
 
add_action( 'admin_menu', 'revcon_change_post_label' );
add_action( 'init', 'revcon_change_post_object' );


/*Slider for Eroding website Archive*/ 
add_shortcode( 'slider', 'slider_func' );
function slider_func( $atts ) {
    $atts = shortcode_atts( array(
        'height' => '700px', 
    'source' => 'slider',    
    ), $atts, 'slider' );
static $asearch_first_call = 1;
$source = $atts["source"];
$height = $atts["height"];
$style0 = '<style>
#prev{
    left:0;
    border-radius: 0 10px 10px 0;
}
#next{
    right:0;
    border-radius:10px 0 0 10px;
}
#prev svg,#next svg{
    width:100%;
    fill: #fff;
}
#prev:hover,
#next:hover{
    background-color: rgba(0, 0, 0, 0.8);
}
</style>
';
$js0 = <<<EOD
<script>
const arrowHtml = '<span class="icon-arrow_back" id="prev"></span><span class="icon-arrow_forward" id="next"></span>'
let arrowIconLeft = '<?xml version="1.0" ?><!DOCTYPE svg  PUBLIC \'-//W3C//DTD SVG 1.1//EN\'  \'https://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\'><svg height="50px" id="Layer_1" style="enable-background:new 0 0 50 50;" version="1.1" viewBox="0 0 512 512" width="50px" color="#fff" xml:space="preserve" xmlns="https://www.w3.org/2000/svg" xmlns:xlink="https://www.w3.org/1999/xlink"><polygon points="352,115.4 331.3,96 160,256 331.3,416 352,396.7 201.5,256 "/></svg>';
</script>
EOD;
$style = '<style>
.'.$source.'{
    position: relative;
    overflow: hidden;
  width: 100%!important;
  height: '.$height.';
  padding: 0px!important;
}
.'.$source.' > div {
    width: 100%!important;
    position: absolute;
    transition: all 1s;
  height: '.$height.';
  margin: 0px!important;
 }
.'.$source.' > div {
  height: '.$height.';
 } 
.'.$source.' > span{
    height: 50px;
    position: absolute;
    top:50%;
    margin:-25px 0 0 0;
    background-color: rgba(0, 0, 0, 0.4);
    color:#fff;
    line-height: 50px;
    text-align: center;
    cursor: pointer;
}
</style>';
$js = <<<EOD
<script>
document.querySelector('.$source').innerHTML += arrowHtml;
let slides$source = document.querySelectorAll('.$source > div');
let slideSayisi$source = slides$source.length;
let prev$source = document.querySelector('.$source #prev');
let next$source = document.querySelector('.$source #next');
prev$source.innerHTML = arrowIconLeft;
next$source.innerHTML = arrowIconLeft;
next$source.querySelector('svg').style.transform = 'rotate(180deg)';
for (let index = 0; index < slides{$source}.length; index++) {
    const element{$source} = slides{$source}[index];
    element{$source}.style.transform = "translateX("+100*(index)+"%)";
}
let loop{$source} = 0 + 1000*slideSayisi{$source};
function goNext{$source}(){
    loop{$source}++;
            for (let index = 0; index < slides{$source}.length; index++) {
                const element{$source} = slides{$source}[index];
                element{$source}.style.transform = "translateX("+100*(index-loop{$source}%slideSayisi{$source})+"%)";
            }
}
function goPrev{$source}(){
    loop{$source}--;
            for (let index = 0; index < slides{$source}.length; index++) {
                const element{$source} = slides{$source}[index];
                element{$source}.style.transform = "translateX("+100*(index-loop{$source}%slideSayisi{$source})+"%)";
            }
}
next{$source}.addEventListener('click',goNext{$source});
prev{$source}.addEventListener('click',goPrev{$source});
document.addEventListener('keydown',function(e){
    if(e.code === 'ArrowRight'){
        goNext{$source}();
    }else if(e.code === 'ArrowLeft'){
        goPrev{$source}();
    }
});
</script>
EOD;
if ( $asearch_first_call == 1 ){  
   $asearch_first_call++;
   return "{$style0}{$style}{$js0}{$js}"; } elseif  ( $asearch_first_call > 1 ) {  $asearch_first_call++;
    return "{$style}{$js}"; }}
